﻿Connect-AzAccount
Set-AzContext -Subscription "Identity-SBX"

<#New-AzDeploymentStack `
    -Name "MyDeploymentStack" `
    -ResourceGroupName "MyResourceGroup" `
    -Location "EastUS" `
    -TemplateFile "C:\path\to\storageStack.bicep"
#>

    $logFile = "C:\_tools\logs\storage_log.txt"

try {
    $deployment = New-AzResourceGroupDeploymentStack  `
        -Name "StorageSBX" `
        -ResourceGroupName "adssbxarmrgp005" `
        -Location "WestUS2" `
        -ActionOnUnmanage "detachAll" `
       -DenySettingsMode "DenyDelete" `
       -Confirm:$false `
        -TemplateFile "C:\_tools\Deploymentssbx\DR\storage.bicep" `
        -verbose | Tee-Object -FilePath $logFile 
        

    Write-Host "Deployment successful. Logs saved to $logFile"
} catch {
$_ | Out-File -FilePath $logFile -Append
    Write-Host "Deployment failed. Check the log file: $logFile"
}