﻿Connect-AzAccount
Invoke-Expression C:\Users\alex\OneDrive\Documents\ALLPRDC.ps1
Invoke-Expression C:\Users\alex\OneDrive\Documents\AllPRDK.ps1
Invoke-Expression C:\Users\alex\OneDrive\Documents\ALLPRDW.ps1
Invoke-Expression C:\Users\alex\OneDrive\Documents\ALLQUTW.ps1
Invoke-Expression C:\Users\alex\OneDrive\Documents\ALLQUTC.ps1
Invoke-Expression C:\Users\alex\OneDrive\Documents\ALLDEVC.ps1
Invoke-Expression C:\Users\alex\OneDrive\Documents\ALLDEVW.ps1