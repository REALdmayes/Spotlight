﻿#Tags
$tagsd = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="DEV";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$tagsp = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="PRD";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$tagsq = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="QUT";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$DenySettings = "DenyDelete"

#$RGName6 = 'adsprdarmrgp006DR'
New-AzResourceGroup -Name adsprdarmrgp006DR -Location centralus  -Tag $tagsp
#$DeploymentStackName6 = 'ADSPRDDSNUSW06DR'
#New-AzResourceGroupDeployment -ResourceGroupName $RGName -TemplateFile ./ADSPRD001z.bicep -adminUsername "amadsdev001z"
New-AzResourceGroupDeploymentStack -Name ADSPRDDSNUSC001DR -TemplateFile C:\_tools\deployments\DR\VNETPRDC.bicep -ResourceGroupName adsprdarmrgp006DR -DenySettingsMode $DenySettings -DenySettingsApplyToChildScopes -ActionOnUnmanage "detachAll"

Start-sleep -Seconds 10

New-AzResourceGroup -Name adsprdarmrgp007DR -Location centralus  -Tag $tagsp

Start-sleep -Seconds 10

New-AzResourceGroupDeploymentStack `
    -ResourceGroupName "adsprdarmrgp007DR" `
    -TemplateFile "C:\_tools\deployments\DR\DCPRDk.bicep" `
    -TemplateParameterFile "C:\_tools\deployments\DR\parametersc.json" `
    -Name "ADSPRDDSNUSC002DR" `
    -Location "centralus" `
    -ActionOnUnmanage "detachAll" `
  -DenySettingsMode "DenyDelete" `
    -Confirm:$false



New-AzResourceGroupDeploymentStack `
    -ResourceGroupName "adsprdarmrgp007DR" `
    -TemplateFile "C:\_tools\deployments\DR\DCPRDk.bicep" `
    -TemplateParameterFile "C:\_tools\deployments\DR\parametersappc.json" `
    -Name "ADSPRDDSNUSC003DR" `
    -Location "centralus" `
    -ActionOnUnmanage "detachAll" `
  -DenySettingsMode "DenyDelete" `
    -Confirm:$false