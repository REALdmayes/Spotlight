﻿Connect-AzAccount
Set-AzContext -Subscription "Identity-SBX"
Remove-AzResourceGroup -Name "adssbxarmrgp005" -Force
Remove-AzResourceGroup -Name "adssbxarmrgp006" -Force
Remove-AzResourceGroup -Name "adssbxarmrgp007" -Force
#Remove-AzResourceGroup -Name "exampleRG" -Force

#Remove-AzResourceGroup -Name "NetworkWatcherRG" -Force
#Remove-AzResourceGroup -Name "adsdevarmrgp007DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp005DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp007DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp009DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp010DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp011DR" -Force
#Remove-AzResourceGroup -Name "adsqutarmrgp007DR" -Force
#Remove-AzResourceGroup -Name "adsqutarmrgp005DR" -Force
#Remove-AzResourceGroup -Name "adsqutarmrgp006DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp006DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp008DR" -Force
#Remove-AzResourceGroup -Name "adsqutarmrgp004DR" -Force
#Remove-AzResourceGroup -Name "adsdevarmrgp004DR" -Force
#Remove-AzResourceGroup -Name "adsdevarmrgp006DR" -Force
#Remove-AzResourceGroup -Name "adsprdarmrgp004DR" -Force