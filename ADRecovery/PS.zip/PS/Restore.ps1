﻿Set-AzContext -Subscription "IDENTITY"

$vault = Get-AzRecoveryServicesVault | Out-GridView -PassThru
Set-AzRecoveryServicesVaultContext -Vault $vault

$vmName = Read-Host "Enter the original VM name to restore"

#$vault = Get-AzRecoveryServicesVault -ResourceGroupName "adsdevarmrgp005" -Name "adsdevarmrevuw2001"
$BackupItem = Get-AzRecoveryServicesBackupItem -BackupManagementType "AzureVM" -WorkloadType "AzureVM" -Name $VMName -VaultId $vault.ID
#$StartDate = (Get-Date).AddDays(-7)
#$EndDate = Get-Date

#$RP = Get-AzRecoveryServicesBackupRecoveryPoint -Item $BackupItem -StartDate $StartDate.ToUniversalTime() -EndDate $EndDate.ToUniversalTime() -VaultId $vault.ID
$RP = Get-AzRecoveryServicesBackupRecoveryPoint -Item $backupItem | Sort-Object RecoveryPointTime -Descending | Out-GridView -PassThru
Set-AzContext -Subscription "IDENTITY-SBX"

$targetRG = Get-AzResourceGroup |Select-object ResourceGroupName | Out-GridView -PassThru

$storageRG = Get-AzResourceGroup | Out-GridView -Title "Select Resource Group for Storage Account" -PassThru
$storageAccount = Get-AzStorageAccount -ResourceGroupName $storageRG.ResourceGroupName | Out-GridView -Title "Select Staging Storage Account" -PassThru


Set-AzContext -Subscription "IDENTITY"

$AlternateLocationRestoreJob = Restore-AzRecoveryServicesBackupItem -RecoveryPoint $RP[0] -TargetSubscriptionId "1eb4ce8f-a169-4e0b-8aab-8cf05fcdebf1" -TargetResourceGroupName $targetRG.ResourceGroupName  -StorageAccountResourceGroupName $storageRG -StorageAccountName $storageAccount.StorageAccountName -TargetVMName "ADSSBX004Z" -TargetVNetResourceGroup "adssbxarmrgp004"  -TargetVNetName "adssbxarmvntuw2001" -TargetSubnetName "adssbxarmsubuw2001"  -VaultId $vault.ID -VaultLocation $vault.Location 
#$OriginalLocationRestoreJob = Restore-AzRecoveryServicesBackupItem -RecoveryPoint $RP[0] -StorageAccountName "DestStorageAccount" -StorageAccountResourceGroupName "DestStorageAccRG" -VaultId $vault.ID -VaultLocation $vault.Location