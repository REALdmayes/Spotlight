﻿#Tags
$tagsd = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="DEV";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$tagsp = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="PRD";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$tagsq = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="dev";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$DenySettings = "DenyDelete"
#dev RG, Subnet and Vnets

#Start-sleep -Seconds 10
New-AzResourceGroup -Name adsdevarmrgp007DR -Location centralus  -Tag $tagsq

New-AzResourceGroup -Name adsdevarmrgp006DR -Location centralus  -Tag $tagsq
Start-sleep -Seconds 20
New-AzResourceGroupDeploymentStack -Name RGSDEVDSNUSC001DR -TemplateFile C:\_tools\deployments\DR\VNETdevC.bicep -ResourceGroupName adsdevarmrgp006DR -DenySettingsMode $DenySettings -DenySettingsApplyToChildScopes -ActionOnUnmanage "detachAll"



Start-sleep -Seconds 10

#Create dev DC Servers
New-AzResourceGroupDeploymentStack `
    -ResourceGroupName "adsdevarmrgp007DR" `
    -TemplateFile "C:\_tools\deployments\DR\DCPRDk.bicep" `
    -TemplateParameterFile "C:\_tools\deployments\DR\parametersdevdcc.json" `
    -Name "ADSDEVDSNUSC001DR" `
    -Location "centralus" `
    -ActionOnUnmanage "detachAll" `
  -DenySettingsMode "DenyDelete" `
    -Confirm:$false

    
<#Create APP Servers

New-AzResourceGroupDeploymentStack `
    -ResourceGroupName "adsdevarmrgp007DR" `
    -TemplateFile "C:\_tools\deployments\DR\DCPRDk.bicep" `
    -TemplateParameterFile "C:\_tools\deployments\DR\parametersdevappc.json" `
    -Name "APPDEVDSNUS001DR" `
    -Location "centralus" `
    -ActionOnUnmanage "detachAll" `
  -DenySettingsMode "DenyDelete" `
    -Confirm:$false
    #>