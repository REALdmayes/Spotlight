﻿#Tags
$tagsd = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="DEV";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$tagsp = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="PRD";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$tagsq = @{"APMID"="APM0002676"; "ApplicationName"="Active Directory Services";"BillingIndicator"="C10500588";"Compliance"="N/A";"Env"="QUT";"DataSensitivity"="INTERNAL";"ITCoreService"="Cloud Services";"SuncorKeyIDApplicationName"="SUN0002724[Active Directory Services]";"SupportStatus"="Project"}
$DenySettings = "DenyDelete"
#QUT RG, Subnet and Vnets


New-AzResourceGroup -Name adsqutarmrgp004DR -Location westus2  -Tag $tagsq
Start-sleep -Seconds 10
#$DeploymentStackName12 = 'ADSQUTDSNUSW10DR'
#New-AzResourceGroupDeployment -ResourceGroupName $RGName -TemplateFile ./ADSPRD001z.bicep -adminUsername "amadsdev001z"
New-AzResourceGroupDeploymentStack -Name RGSQUTDSNUSW001DR -TemplateFile C:\_tools\deployments\DR\VNETQUTW.bicep -ResourceGroupName adsqutarmrgp004DR -DenySettingsMode $DenySettings -DenySettingsApplyToChildScopes -ActionOnUnmanage "detachAll"


Start-sleep -Seconds 10
New-AzResourceGroup -Name adsqutarmrgp005DR -Location westus2  -Tag $tagsq

Start-sleep -Seconds 10

#Create QUT DC Servers
New-AzResourceGroupDeploymentStack `
    -ResourceGroupName "adsqutarmrgp005DR" `
    -TemplateFile "C:\_tools\deployments\DR\DCPRDk.bicep" `
    -TemplateParameterFile "C:\_tools\deployments\DR\parametersqutdcw.json" `
    -Name "ADSQUTDSNUSW001DR" `
    -Location "westus2" `
    -ActionOnUnmanage "detachAll" `
  -DenySettingsMode "DenyDelete" `
    -Confirm:$false

    
#Create APP Servers

#Create QUT DC Servers
New-AzResourceGroupDeploymentStack `
    -ResourceGroupName "adsqutarmrgp005DR" `
    -TemplateFile "C:\_tools\deployments\DR\DCPRDk.bicep" `
    -TemplateParameterFile "C:\_tools\deployments\DR\parametersqutappw.json" `
    -Name "APPQUTDSNUSW001DR" `
    -Location "westus2" `
    -ActionOnUnmanage "detachAll" `
  -DenySettingsMode "DenyDelete" `
    -Confirm:$false